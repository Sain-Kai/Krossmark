// Change to your laptop IP when running on a real device
// For Android emulator use 10.0.2.2, for real device use your laptop IP
const BASE_URL = "http://10.0.2.2:8000/api/v1";

// ── Latest analysis result ─────────────────────────────────────────
export const getLatestResult = async () => {
  try {
    const res = await fetch(`${BASE_URL}/results/latest/`);
    if (res.status === 404) return { status: "no_data" };
    if (!res.ok) return { status: "error" };
    const data = await res.json();
    return { status: "ok", data };
  } catch {
    return { status: "error" };
  }
};

// ── All alerts (unacknowledged first) ─────────────────────────────
export const getAlerts = async () => {
  try {
    const res = await fetch(`${BASE_URL}/alerts/`);
    if (!res.ok) return [];
    const data = await res.json();
    // DRF returns {count, results} or plain array
    return Array.isArray(data) ? data : (data.results ?? []);
  } catch {
    return [];
  }
};

// ── Acknowledge an alert ───────────────────────────────────────────
export const ackAlert = async (id: string) => {
  try {
    const res = await fetch(`${BASE_URL}/alerts/${id}/ack/`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ack_by: "mobile-app" }),
    });
    return res.ok;
  } catch {
    return false;
  }
};

// ── All registered devices ─────────────────────────────────────────
export const getDevices = async () => {
  try {
    const res = await fetch(`${BASE_URL}/devices/`);
    if (!res.ok) return [];
    const data = await res.json();
    return Array.isArray(data) ? data : (data.results ?? []);
  } catch {
    return [];
  }
};

// ── Recent burst captures ──────────────────────────────────────────
export const getBursts = async () => {
  try {
    const res = await fetch(`${BASE_URL}/bursts/`);
    if (!res.ok) return [];
    const data = await res.json();
    return Array.isArray(data) ? data : (data.results ?? []);
  } catch {
    return [];
  }
};

// ── Recent results list ────────────────────────────────────────────
export const getResults = async () => {
  try {
    const res = await fetch(`${BASE_URL}/results/`);
    if (!res.ok) return [];
    const data = await res.json();
    return Array.isArray(data) ? data : (data.results ?? []);
  } catch {
    return [];
  }
};

// ── Health check ───────────────────────────────────────────────────
export const getHealth = async () => {
  try {
    const res = await fetch(`${BASE_URL.replace("/api/v1", "")}/api/health/`);
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
};
