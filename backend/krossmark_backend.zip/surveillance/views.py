import subprocess
import sys
import threading

from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from rest_framework import status, viewsets
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.decorators import action
from rest_framework.permissions import AllowAny
from rest_framework.parsers import JSONParser, MultiPartParser, FormParser

from .models import Device, TriggerEvent, BurstCapture, AnalysisResult, Alert
from .serializers import (
    DeviceSerializer,
    DeviceRegisterSerializer,
    TriggerEventSerializer,
    BurstCaptureSerializer,
    AnalysisResultSerializer,
    AlertSerializer,
)
from .auth import DeviceKeyAuthentication
from .services.analysis_service import AnalysisOrchestrator


class HealthCheckView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        return Response({
            "status": "ok",
            "service": "krossmark-backend",
            "time": timezone.now().isoformat(),
        })


class DeviceViewSet(viewsets.ModelViewSet):
    queryset = Device.objects.all().order_by("-created_at")
    serializer_class = DeviceSerializer
    permission_classes = [AllowAny]

    @action(detail=False, methods=["post"], url_path="register")
    def register(self, request):
        serializer = DeviceRegisterSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        device = Device.objects.create(**serializer.validated_data)
        return Response(DeviceSerializer(device).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["get"], url_path="status")
    def device_status(self, request, pk=None):
        device = self.get_object()
        return Response({
            "device_id": str(device.id),
            "name": device.name,
            "device_type": device.device_type,
            "is_active": device.is_active,
            "last_seen": device.last_seen,
            "created_at": device.created_at,
        })


class TriggerEventViewSet(viewsets.ModelViewSet):
    queryset = TriggerEvent.objects.select_related("device").all().order_by("-created_at")
    serializer_class = TriggerEventSerializer
    authentication_classes = [DeviceKeyAuthentication]
    permission_classes = [AllowAny]
    parser_classes = [JSONParser]

    def perform_create(self, serializer):
        device = None
        key = self.request.headers.get("X-Device-Key")
        auth = self.request.headers.get("Authorization", "")
        if not key and auth.startswith("Device "):
            key = auth.split(" ", 1)[1].strip()
        if key:
            device = Device.objects.filter(api_key=key, is_active=True).first()
        if device is None:
            raise ValueError("A valid device key is required.")
        device.last_seen = timezone.now()
        device.save(update_fields=["last_seen"])
        serializer.save(device=device)


class BurstCaptureViewSet(viewsets.ModelViewSet):
    queryset = BurstCapture.objects.select_related("device", "trigger").all().order_by("-created_at")
    serializer_class = BurstCaptureSerializer
    authentication_classes = [DeviceKeyAuthentication]
    permission_classes = [AllowAny]
    parser_classes = [MultiPartParser, FormParser, JSONParser]

    def create(self, request, *args, **kwargs):
        data = request.data.copy()
        device_id = data.get("device_id")
        trigger_id = data.get("trigger_id")

        device = Device.objects.filter(id=device_id).first() if device_id else None
        trigger = TriggerEvent.objects.filter(id=trigger_id).first() if trigger_id else None

        if device is None:
            return Response(
                {"detail": "device_id is required and must be valid."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        burst = BurstCapture.objects.create(
            device=device,
            trigger=trigger,
            frame_count=int(data.get("frame_count") or 0),
            audio_sample_rate=int(data.get("audio_sample_rate") or 48000),
            metadata=data.get("metadata") if isinstance(data.get("metadata"), dict) else {},
        )

        if "video_file" in request.FILES:
            burst.video_file = request.FILES["video_file"]
        if "audio_file" in request.FILES:
            burst.audio_file = request.FILES["audio_file"]
        burst.save()

        try:
            result = AnalysisOrchestrator().analyze_and_persist(burst)
            return Response({
                "burst": BurstCaptureSerializer(burst).data,
                "result": AnalysisResultSerializer(result).data,
            }, status=status.HTTP_201_CREATED)
        except Exception as exc:
            burst.status = BurstCapture.Status.FAILED
            burst.error_message = str(exc)
            burst.save(update_fields=["status", "error_message"])
            return Response({"detail": str(exc)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @action(detail=True, methods=["post"], url_path="analyze")
    def analyze(self, request, pk=None):
        burst = self.get_object()
        result = AnalysisOrchestrator().analyze_and_persist(burst)
        return Response({
            "burst": BurstCaptureSerializer(burst).data,
            "result": AnalysisResultSerializer(result).data,
        })


class AnalysisResultViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = AnalysisResult.objects.select_related(
        "burst", "burst__device"
    ).all().order_by("-created_at")
    serializer_class = AnalysisResultSerializer
    permission_classes = [AllowAny]

    @action(detail=False, methods=["get"], url_path="latest")
    def latest(self, request):
        result = self.get_queryset().first()
        if not result:
            return Response({}, status=status.HTTP_404_NOT_FOUND)
        return Response(self.get_serializer(result).data)


class AlertViewSet(viewsets.ModelViewSet):
    queryset = Alert.objects.select_related(
        "analysis_result", "analysis_result__burst"
    ).all().order_by("-created_at")
    serializer_class = AlertSerializer
    permission_classes = [AllowAny]

    @action(detail=True, methods=["post"], url_path="ack")
    def ack(self, request, pk=None):
        alert = self.get_object()
        alert.acknowledged = True
        alert.ack_by = request.data.get("ack_by", "dashboard")
        alert.save(update_fields=["acknowledged", "ack_by"])
        return Response(self.get_serializer(alert).data)


class IngestAndAnalyzeView(APIView):
    """
    Receives video + audio from Raspberry Pi.
    Runs the full AI pipeline and saves result to DB.
    """
    authentication_classes = [DeviceKeyAuthentication]
    permission_classes = [AllowAny]
    parser_classes = [MultiPartParser, FormParser, JSONParser]

    def post(self, request):
        data = request.data
        device_id = data.get("device_id")
        device = Device.objects.filter(id=device_id).first()

        # Also allow serial_number lookup — Pi sends serial not UUID
        if device is None:
            device = Device.objects.filter(serial_number=device_id).first()

        if device is None:
            return Response(
                {"detail": "device_id missing or invalid"},
                status=status.HTTP_400_BAD_REQUEST,
            )

        trigger = None
        trigger_id = data.get("trigger_id")
        if trigger_id:
            trigger = TriggerEvent.objects.filter(id=trigger_id).first()

        burst = BurstCapture.objects.create(
            device=device,
            trigger=trigger,
            frame_count=int(data.get("frame_count") or 0),
            audio_sample_rate=int(data.get("audio_sample_rate") or 8000),
            metadata=data.get("metadata") if isinstance(data.get("metadata"), dict) else {},
        )

        if "video_file" in request.FILES:
            burst.video_file = request.FILES["video_file"]
        if "audio_file" in request.FILES:
            burst.audio_file = request.FILES["audio_file"]
        burst.save()

        result = AnalysisOrchestrator().analyze_and_persist(burst)

        # Auto-create alert if threat >= 3
        if result.threat_level >= 3:
            from .services.pipeline_adapter import result_to_alert_severity
            Alert.objects.create(
                analysis_result=result,
                severity=result_to_alert_severity(result.threat_level),
                title=f"Threat level {result.threat_level} — {result.scene_intent}",
                message=result.briefing or "Threat detected.",
            )

        return Response({
            "burst": BurstCaptureSerializer(burst).data,
            "result": AnalysisResultSerializer(result).data,
        }, status=status.HTTP_201_CREATED)


# ── ESP32 direct trigger (laptop webcam fallback) ──────────────────────────────
@method_decorator(csrf_exempt, name="dispatch")
class ESP32TriggerView(APIView):
    """
    Used when testing with laptop webcam only (no Node2 camera).
    Runs the full pipeline in a background thread using the laptop camera.
    In production the Pi posts to /ingest/ instead.
    """
    permission_classes = [AllowAny]

    def post(self, request):
        def run_pipeline():
            import sys, os, cv2, time
            import numpy as np
            import sounddevice as sd

            KROSSMARK_DIR = r"E:\Krossmark"
            if KROSSMARK_DIR not in sys.path:
                sys.path.insert(0, KROSSMARK_DIR)

            import vision.core.config as config
            from vision.core.pipeline.defence_ai_pipeline import DefenseAIPipeline
            from vision.core.detection.yolo import YoloDetector
            from vision.core.tracking.deepsort_tracker import DeepSortTracker
            from vision.core.pose.rtm_pose import RTMPoseEstimator
            from vision.core.vlm.ollama_vl import OllamaVLM
            from vision.core.audio.worker import HTSATWorker

            print("[ESP32View] Loading models...")
            detector = YoloDetector(
                config.YOLO_DET_MODEL,
                conf=config.CONF_THRESH,
                iou=config.IOU_THRESH,
                imgsz=config.YOLO_IMGSZ,
            )
            tracker = DeepSortTracker()

            class DummyRTMModel:
                def infer(self, crop):
                    h, w, _ = crop.shape
                    return {
                        "left_wrist":     (w * 0.3, h * 0.4),
                        "right_wrist":    (w * 0.7, h * 0.4),
                        "left_elbow":     (w * 0.3, h * 0.5),
                        "right_elbow":    (w * 0.7, h * 0.5),
                        "left_shoulder":  (w * 0.3, h * 0.6),
                        "right_shoulder": (w * 0.7, h * 0.6),
                    }

            pose  = RTMPoseEstimator(DummyRTMModel())
            htsat = HTSATWorker(config.HTSAT_MODEL)
            vlm   = OllamaVLM(model_name=config.QWEN_MODEL_NAME)

            pipeline = DefenseAIPipeline(
                detector=detector, tracker=tracker,
                pose_estimator=pose, vlm=vlm, htsat=htsat,
            )

            print("[ESP32View] Capturing burst...")
            cap = cv2.VideoCapture(config.VIDEO_SOURCE)
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

            frames = []
            audio_buf = sd.rec(
                int(config.BURST_SECONDS * config.AUDIO_SAMPLE_RATE),
                samplerate=config.AUDIO_SAMPLE_RATE,
                channels=1, dtype="float32",
            )
            t0 = time.time()
            while time.time() - t0 < config.BURST_SECONDS:
                ret, frame = cap.read()
                if ret:
                    frames.append(frame)
            sd.wait()
            cap.release()
            audio = audio_buf.flatten()

            print(f"[ESP32View] {len(frames)} frames captured. Running AI...")
            result = pipeline.analyze_burst(frames, audio)
            print(f"[ESP32View] Threat={result.get('threat_level')} "
                  f"Conf={result.get('confidence')}")

            # Save to DB
            from backend.surveillance.models import Device, BurstCapture, AnalysisResult, Alert
            from backend.surveillance.services.pipeline_adapter import result_to_alert_severity

            device, _ = Device.objects.get_or_create(
                serial_number="ESP32-IR-001",
                defaults={
                    "name": "ESP32 IR Node",
                    "device_type": "sensor",
                    "location_tag": "front-door",
                },
            )
            burst = BurstCapture.objects.create(
                device=device,
                frame_count=len(frames),
                metadata={"people_hint": len(result.get("actors", [])) or 1},
            )
            ar = AnalysisResult.objects.create(
                burst=burst,
                threat_level=int(result.get("threat_level", 1) or 1),
                confidence=float(result.get("confidence", 0.0) or 0.0),
                group_intent=str(result.get("group_intent", "")),
                scene_intent=str(result.get("scene_intent", "Not Calculated")),
                decision=str(result.get("decision", "")),
                briefing=str(result.get("briefing", "")),
                audit=result.get("audit", {}),
                actors=result.get("actors", []),
                video_context=result.get("video_context", {}),
                raw_output=result,
            )

            if ar.threat_level >= 3:
                Alert.objects.create(
                    analysis_result=ar,
                    severity=result_to_alert_severity(ar.threat_level),
                    title=f"Threat level {ar.threat_level} detected",
                    message=ar.briefing or "Threat detected.",
                )

            print("[ESP32View] Saved to DB — app will update.")

        threading.Thread(target=run_pipeline, daemon=True).start()
        return Response({"status": "triggered", "message": "Pipeline started"}, status=202)